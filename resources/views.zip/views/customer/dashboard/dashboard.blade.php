@extends('customer.layout.main')
@section('title','Dashboard')
@section('style')
<style type="text/css">
	#veh_summary:hover{
		color: #000;
		cursor: pointer;
	}
	#ship_summary:hover{
		color: #000;
		cursor: pointer;
	}
</style>
@stop
@section('content')
<div class="site-content">
	<!-- Content -->
	<div class="content-area py-1">
		<div class="container-fluid">
			<div class="row row-md">
				<div class="col-lg-4 col-md-6 col-xs-12">
					<div class="box box-block bg-white tile tile-1 mb-2">
						<div class="t-icon right"><span class="bg-danger"></span><i class="ti-car"></i></div>
						<div class="t-content">
							<h6 class="text-uppercase mb-1">Vehicles</h6>
							<h1 class="mb-1">{{@$vehicles}}</h1>
							<i class="fa fa-caret-up text-success mr-0-5"></i><span>View All Vehicles</span>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-xs-12">
					<div class="box box-block bg-white tile tile-1 mb-2">
						<div class="t-icon right"><span class="bg-success"></span><i class="ti-bar-chart"></i></div>
						<div class="t-content">
							<h6 class="text-uppercase mb-1">Shipments</h6>
							<h1 class="mb-1">{{@$containers}}</h1>
							<i class="fa fa-caret-up text-success mr-0-5"></i><span>View All Shipments</span>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-xs-12">
					<div class="box box-block bg-white tile tile-1 mb-2">
						<div class="t-icon right"><span class="bg-primary"></span><i class="ti-package"></i></div>
						<div class="t-content">
							<h6 class="text-uppercase mb-1">Invoices</h6>
							<h1 class="mb-1">{{@$invoices}}</h1>
							<i class="fa fa-caret-up text-success mr-0-5"></i><span>View All Invoices</span>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="box bg-white text-xs-center">
						<div class="box-block pb-1" style="margin-top:4%; margin-bottom:5%;">
							<h5 class="mb-2">Invoice Balance</h5>
							<div id="donut" class="chart-container demo-chart-2"></div>
						</div>
					</div>
				</div>
				<div class="col-md-8">
					<ul class="nav nav-tabs" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" id="veh_summary"><b>Vehicle Summary</b></a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-muted" id="ship_summary"><b>Shipment Summary</b></a>
						</li>
					</ul>
					<div class="box box-block bg-white b-t-0 mb-2">
						<div class="tables-responsive">
						    <table class="table table-grey-head mb-md-0 tables-responsive">
								<tbody id="vehicle_summary">	
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			<div class="row row-md mb-2">
				<div class="col-md-4">
					<div class="box bg-white text-xs-center">
						<div class="box-block pb-1">
							<img class="img img-rouded" width="290px" height="285px" src="{{asset('img/logo.png')}}">
						</div>
					</div>
				</div>
				<div class="col-md-8">
					<div class="box bg-white" style="min-height: 315px; max-height: 320px; overflow-x: scroll;">
						<table class="table table-grey-head mb-md-0">
							<thead>
								<tr>
									<th>#</th>
									<th>Subject</th>
									<th>Content</th>
									<th>Time</th>
								</tr>
							</thead>
							<tbody>
								<?php $id=1; ?>
								@foreach($messages as $message)
								<tr>
									<th scope="row">{{$id++}}</th>
									<td>{{$message->subject}}</td>
									<td>
										<a class="text-primary" href="{{route('message_detail_customer',$message->id)}}"><span class="underline">{{substr($message->content,0,30)}}</span></a>
									</td>
									<td>
										<span class="text-muted">{{ Carbon\Carbon::parse($message->created_at)->diffForHumans()}}</span>
									</td>
								</tr>
								@endforeach
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Footer -->
	<footer class="footer">
		<div class="container-fluid">
			<div class="row text-xs-center">
				<div class="col-sm-4 text-sm-left mb-0-5 mb-sm-0">
					2020 © PGL
				</div>
				<div class="col-sm-8 text-sm-right">
					<ul class="nav nav-inline l-h-2">
						<li class="nav-item"><a class="nav-link text-black" href="#">Privacy</a></li>
						<li class="nav-item"><a class="nav-link text-black" href="#">Terms</a></li>
						<li class="nav-item"><a class="nav-link text-black" href="#">Help</a></li>
					</ul>
				</div>
			</div>
		</div>
	</footer>
</div>
@stop
@section('js')
	<script type="text/javascript">
		$(document).ready(function(){
		  Morris.Donut({
	        element: 'donut',
	        data: [{
	            label: "Paid",
	            value: "{{@$paidInvoice}}",

	        },{
	            label: "All",
	            value: "{{@$allInvoice}}"
	        },{
	            label: "Open",
	            value: "{{@$openInvoice}}"
	        }],
	        resize: true,
	        colors:['#43b968', '#f59345', '#f44236']
	      });
	      vehicle_summary();
	      // load vehicle
	      function vehicle_summary(){
	      	$('#vehicle_summary').html("<div style='text-align:center'><img width='40px' src='img/loading.gif' alt='Loading ...'> </div>");
		       var request = $.ajax({
	              url: "{{url('vehicle_summary')}}",
	              method: "GET",
	              data: {},
	              dataType: "json"
	            });
	             
	            request.done(function( msg ) {
	              // $('#spinnerveh').addClass('hide');
	              // $('.vehdiv').addClass('hide');
	              $('#vehicle_summary').html(msg)
	            });
	             
	            request.fail(function( jqXHR, textStatus ) {
	              alert( "Request failed: " + textStatus );
	            });
            }
            // vehicle summary load
              $('#veh_summary').click(function(){
              	$('#vehicle_summary').html("<div style='text-align:center'><img width='40px' src='img/loading.gif' alt='Loading ...'> </div>");
              	$('#ship_summary').removeClass('active');
              	$('#veh_summary').addClass('active');
		       var request = $.ajax({
	              url: "{{url('vehicle_summary')}}",
	              method: "GET",
	              data: {},
	              dataType: "json"
	            });
	             
	            request.done(function( msg ) {
	              // $('#spinnerveh').addClass('hide');
	              // $('.vehdiv').addClass('hide');
	              $('#vehicle_summary').html(msg)
	            });
	             
	            request.fail(function( jqXHR, textStatus ) {
	              alert( "Request failed: " + textStatus );
	            });
              });
            // shipment summary load
              $('#ship_summary').click(function(){
              	$('#vehicle_summary').html("<div style='text-align:center'><img width='40px' src='img/loading.gif' alt='Loading ...'> </div>");
              	$('#veh_summary').removeClass('active');
              	$('#ship_summary').addClass('active');
            	var request = $.ajax({
	              url: "{{url('shipment_summary')}}",
	              method: "GET",
	              data: {},
	              dataType: "json"
	            });
	             
	            request.done(function( msg ) {
	              // $('#spinnerveh').addClass('hide');
	              // $('.vehdiv').addClass('hide');
	              $('#vehicle_summary').html(msg)
	            });
	             
	            request.fail(function( jqXHR, textStatus ) {
	              alert( "Request failed: " + textStatus );
	            });
            });

	     });
	</script>
@stop
